
var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider,$locationProvider) {
    $routeProvider
        .when("/", {
            title:"main page ",
            desc : "main page desc",
            templateUrl : "pages2/main.html",
        })
        .when("/london/:param1/:param2", {
            title:"london page ",
            desc : "london page desc",
            templateUrl : "pages2/london.html",
            controller : "londonCtrl"
        })
        .when("/paris", {
            title:"paris page ",
            desc :"paris page desc",
            templateUrl : "pages2/paris.html",
            controller : "parisCtrl"
        });
    // $locationProvider.html5Mode(true);
});

app.run(['$rootScope', function ($rootScope) {
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        $rootScope.title = current.$$route.title;
        $rootScope.description = current.$$route.desc;
    });
}]);

app.controller("londonCtrl", function ($scope,$routeParams) {
    $scope.msg = "I love London"+ $routeParams.param1 +" ----- "+$routeParams.param2 ;
});
app.controller("parisCtrl", function ($scope) {
    $scope.msg = "I love Paris";
});

